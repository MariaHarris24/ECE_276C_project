######README for running the code for training the model######

The .zip folder contains three .py files:

1) main_multiTd3.py: The main function where the training is executed. All parameters have already been set. By default, the code trains on "Ant-v2"
2) TD3.py:           Contains the models for the Actor & Critic, and the TD3 class
3) utils1.py:        This file contains the experience replay buffer class


###Training the model####
You can train the model by simply opening the main_multiTd3.py in an IDE like visual studio or spyder and pressing run
or, you could use the cmd to run the file.

